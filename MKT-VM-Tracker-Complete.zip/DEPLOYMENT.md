# Marketing VM Tracker - Deployment Guide

## 📦 What's Included

This package contains the **Marketing VM Tracker** application - a tool for managing OKRs and Value Metrics with AI-powered analysis.

### Features
- 🎯 **OKR Management** - Upload and manage Objectives and Key Results
- 📊 **Value Metrics** - Submit and analyze Value Metric proposals
- 🤖 **AI Analysis** - Powered by OpenAI via OpenRouter
- 📄 **TOML Format** - All inputs and outputs use human-readable TOML format
- 🖼️ **Image Extraction** - Automatically extract OKR data from screenshots using GPT-4 Vision

---

## 🚀 Quick Deployment Options

### Option 1: Static File Hosting (Easiest)

The `dist` folder contains all the files you need. Simply upload them to any static hosting service:

**Popular Options:**
- **Netlify**: Drag and drop the `dist` folder to [netlify.com/drop](https://app.netlify.com/drop)
- **Vercel**: Run `npx vercel --prod` in the project directory
- **GitHub Pages**: Push to a GitHub repo and enable Pages
- **AWS S3**: Upload to an S3 bucket with static website hosting enabled

### Option 2: Local Server

If you want to run it locally:

```bash
# Install a simple HTTP server
npm install -g serve

# Serve the dist folder
serve dist -p 3000
```

Then open http://localhost:3000 in your browser.

### Option 3: Share the ZIP File

The `MKT-VM-Tracker.zip` file (113KB) contains everything needed. Your colleagues can:

1. **Unzip the file**
2. **Open `index.html`** directly in a browser (for local use)
   - OR upload to any web hosting service

---

## 📋 Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for AI features)

---

## 🔑 API Keys

The application uses the following API keys (already configured):

- **OpenAI API** (for VM analysis): `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`
- **OpenRouter API** (for OKR extraction): `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`

> ⚠️ **Note**: These keys are embedded in the code. For production use, consider implementing proper API key management.

---

## 💾 Data Storage

- All data is stored in **browser localStorage**
- Data persists between sessions
- Each user's data is isolated to their browser
- No backend server required

---

## 🛠️ For Developers

If your colleagues want to modify the code:

```bash
# Clone or extract the source code
cd "MKT VM"

# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

---

## 📖 Usage Guide

### Managing OKRs
1. Navigate to **🎯 OKR** tab
2. Click **📸 Upload New OKR**
3. Upload a screenshot of your OKR
4. AI will automatically extract data in TOML format
5. Review and save

### Analyzing Value Metrics
1. Navigate to **📊 VM** tab
2. Click **➕ Submit New VM**
3. Fill in the VM details
4. Link to an OKR
5. Click **🚀 Analyze** to get AI-powered insights
6. View results with TOML output (copy-friendly)

---

## 🐛 Troubleshooting

**Blank screen?**
- Clear browser cache and reload
- Check browser console for errors
- Ensure you're using a modern browser

**AI features not working?**
- Check internet connection
- API keys may have expired (contact admin)

**Data disappeared?**
- Check if localStorage was cleared
- Each browser/device has separate data

---

## 📞 Support

For issues or questions, contact the development team.

---

## 📄 License

Internal use only - Marketing Team
